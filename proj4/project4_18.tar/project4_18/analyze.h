#ifndef ANALYZE_H
#define ANALYZE_H

#include "globals.h"
void buildSymtab(TreeNode *);

void typeCheck(TreeNode *);

#endif
